package consts;

public class ConstFont {

    public final static String LINE = "--";
    public final static String DEFAULT = "|-1|";
    public final static String BOLD_DARK = "|0|";
    public final static String BOLD_GREEN = "|1|";
    public final static String BOLD_BLUE = "|2|";
    public final static String RED = "|3|";
    public final static String GREEN = "|4|";
    public final static String BLUE = "|5|";
    public final static String BOLD_RED = "|7|";
    public final static String BOLD_YELLOW = "|8|";
    public final static String CENTER = "2|";
    public final static String RIGHT = "1|";

}
