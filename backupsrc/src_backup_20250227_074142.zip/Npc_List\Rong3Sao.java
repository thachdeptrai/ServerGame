package Npc_List;

/**
 *
 * @author NgocThach
 */

public class Rong3Sao extends Rong1Sao {

    public Rong3Sao(int mapId, int status, int cx, int cy, int tempId, int avartar) {
        super(mapId, status, cx, cy, tempId, avartar);
    }

}
