// 
// Decompiled by Procyon v0.6.0
// 

package network.inetwork;

public interface IKeySessionHandler
{
    void sendKey(final ISession p0);
}
