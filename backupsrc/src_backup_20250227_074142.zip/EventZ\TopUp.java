package EventZ;

/**
 *
 * @author NgocThach
 */

import consts.ConstNpc;
import Abstract.Event;

public class TopUp extends Event {

    @Override
    public void npc() {
    }

}
