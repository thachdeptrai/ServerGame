package consts;

/**
 *
 * @author NgocThach
 */

public class ConstAchievement {

    public static final int GIA_NHAP_VE_BINH = 0;
    public static final int SUC_MANH_SIEU_CAP = 1;
    public static final int NONG_DAN_CHAM_CHI = 2;
    public static final int TRAM_TRAN_TRAM_THANG = 3;
    public static final int NOI_CONG_CAO_CUONG = 4;
    public static final int KHINH_CONG_THANH_THAO = 5;
    public static final int THO_SAN_THIEN_XA = 6;
    public static final int TAP_LUYEN_BAI_BAN = 7;
    public static final int HOAT_DONG_CHAM_CHI = 8;
    public static final int HO_TRO_DONG_DOI = 9;
    public static final int TRUM_NHAT_VE_CHAI = 10;
    public static final int LAN_DAU_NAP_NGOC = 11;
    public static final int DANH_BAI_SIEU_QUAI = 12;
    public static final int THANH_HOI_SINH = 13;
    public static final int KY_NANG_THANH_THAO = 14;
    public static final int TRUM_NHAT_NGOC = 15;
    public static final int DAT_15_TRIEU_SUC_MANH = 16;
    public static final int TUYET_KY_THANH_THAO = 17;
    public static final int CHAM_SOC_DAC_BIET = 18;
    public static final int TRUM_KET_LIEU_BOSS = 19;
}
