// 
// Decompiled by Procyon v0.6.0
// 

package network.inetwork;

public interface ISessionAcceptHandler
{
    void sessionInit(final ISession p0);
    
    void sessionDisconnect(final ISession p0);
}
