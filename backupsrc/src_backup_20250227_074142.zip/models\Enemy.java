package models;

import player.Friend;

/*
 *
 *
 * @author NgocThach
 */

public class Enemy extends Friend {

}
