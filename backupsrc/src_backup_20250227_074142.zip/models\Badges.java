/*
 * Copyright by NgocThach
 */

package models;

public class Badges {

    public int idBadges = -1;
    public long lastTimeSendBadges;

}
