// 
// Decompiled by Procyon v0.6.0
// 

package network.inetwork;

public interface IServerClose
{
    void serverClose();
}
