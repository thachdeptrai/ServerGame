package player;

/*
 *
 *
 * @author NgocThach
 */

public class Friend {

    public int id;
    public String name;
    public short head;
    public short body;
    public short leg;
    public byte bag;
    public long power;
    public boolean online;

}
