package EventZ;

/**
 *
 * @author NgocThach
 */

import boss.BossID;
import Abstract.Event;

public class Default extends Event {

    @Override
    public void boss() {
//        createBoss(BossID.SUPER_BROLY, 5);
    }

}
