package FunC;

public class VongQuayMayMan {

    public VongQuayMayMan(int luotQuay, int vanMay) {
        this.luotQuay = luotQuay;
        this.vanMay = vanMay;
    }
    ;
    public int luotQuay = 0;
    public int vanMay = 0;
}
