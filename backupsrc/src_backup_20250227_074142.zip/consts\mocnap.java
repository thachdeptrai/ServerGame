package consts;

public class mocnap {

    public static int thoiVang_ = 457;
    //////////////////////////////////////////// Moc 10K
    public static int i10_1 = 457;
    public static int sli10_1 = 10;
    
    public static int i10_2 = 457;
    public static int sli10_2 = 10;

    //////////////////////////////////////////// Moc 20
    public static int i20_1 = 1111;
    public static int sli20_1 = 10;
    
    public static int i20_2 = 16;
    public static int sli20_2 = 10;
    /////////////////////////////////////////// Moc 30
    public static int i30_1 = 457;
    public static int sli30_1 = 20;
    
    public static int i30_2 = 457;
    public static int sli30_2 = 30;
    ///////////////////////////////////////// Moc 50
    public static int i50_1 = 457; // hop tl thuong
    public static int sli50_1 = 1;
    
    public static int i50_2 = 457;
    public static int sli50_2 = 5;
    /////////////////////////////////////////// moc 70
    public static int i70_1 = 1207;
    public static int sli70_1 = 1;
    public static int csi70_1 = 15;
    
    public static int i70_2 = 14;
    public static int sli70_2 = 8;
    
    public static int i70_3 = 15;
    public static int sli70_3 = 8;

    public static int i70_4 = 16;
    public static int sli70_4 = 8;
    ///////////////////////////////////////////////// moc 100
    public static int i100_1 = 457;
    public static int sli100_1 = 3;

    public static int i100_2 = 457;
    public static int sli100_2 = 1;
//    public static int csi100_2 = 12000;

    public static int i100_3 = 457;
    public static int sli100_3 = 100;

    /////////////////////////////////////////////////// moc 200
    public static int i200_1 = 457;
    public static int sli200_1 = 1;
//    public static int csi200_1 = 31;

    public static int i200_2 = 457;
    public static int sli200_2 = 5;
    public static int csi200_2 = 5;

    public static int i200_3 = 457;
    public static int sli200_3 = 130;

    ///////////////////////////////////////////////////// Moc 300
    public static int i300_1 = 457;
    public static int sli300_1 = 5;

    public static int i300_2 = 457;
    public static int sli300_2 = 30;

    public static int i300_3 = 457;
    public static int sli300_3 = 1;
    /////////////////////////////////////////////////////////// Moc 500
    public static int i500_1 = 457;
    public static int sli500_1 = 1;
    public static int sdi500_1 = 22;
    public static int hpi500_1 = 22;
    public static int kii500_1 = 22;
    public static int sdcmi500_1 = 15;

    public static int i500_2 = 1136;
    public static int sli500_2 = 1;

    public static int i500_3 = 457;
    public static int sli500_3 = 250;

    public static int i500_4 = 1441;
    public static int sli500_4 = 10;
    public static int csi500_4 = 5;
    /////////////////////////////////////////////////////////////// Moc 1000
    public static int i1000_1 = 457;
    public static int sli1000_1 = 3;

    public static int i1000_2 = 457;
    public static int sli1000_2 = 10;

    public static int i1000_3 = 457;
    public static int sli1000_3 = 1;
    public static int sdi1000_3 = 25;
    public static int hpi1000_3 = 25;
    public static int kii1000_3 = 25;
    public static int sdcmi1000_3 = 18;

    public static int i1000_4 = 457;
    public static int sli1000_4 = 40;

    public static int i1000_5 = 457;
    public static int sli1000_5 = 40;

    /////////////////////////////////////////////////////////////// Moc 2000
    public static int i2000_1 = 457;
    public static int sli2000_1 = 5;

    public static int i2000_2 = 457;
    public static int sli2000_2 = 15;

    public static int i2000_3 = 457;
    public static int sli2000_3 = 1;
    public static int sdi2000_3 = 45;
    public static int hpi2000_3 = 45;
    public static int kii2000_3 = 45;
    public static int sdcmi2000_3 = 32;

    public static int i2000_4 = 457;
    public static int sli2000_4 = 100;

    public static int i2000_5 = 457;
    public static int sli2000_5 = 999;
    /////////////////////////////////////////////////////////////// Moc 3000
    public static int i3000_1 = 457;
    public static int sli3000_1 = 10;

    public static int i3000_2 = 457;
    public static int sli3000_2 = 10;

    public static int i3000_3 = 457;
    public static int sli3000_3 = 10;

    public static int i3000_4 = 1599;
    public static int sli3000_4 = 159;

    public static int i3000_5 = 457;
    public static int sli3000_5 = 399;

    public static int i3000_6 = 1598;
    public static int sli3000_6 = 159;
    public static int i3000_7 = 1597;
    public static int sli3000_7 = 159;
    public static int i3000_8 = 1596;
    public static int sli3000_8 = 159;
    //////////////////////////////////////////////////////////////// Moc 5000
    public static int i5000_1 = 457;
    public static int sli5000_1 = 8;

    public static int i5000_2 = 1619;
    public static int sli5000_2 = 15;

    public static int i5000_3 = 1513;
    public static int sli5000_3 = 1;
    public static int sdi5000_3 = 47;
    public static int hpi5000_3 = 47;
    public static int kii5000_3 = 47;
    public static int sdcmi5000_3 = 36;
    public static int sddepi5000_3 = 12;

    public static int i5000_4 = 1599;
    public static int sli5000_4 = 199;

    public static int i5000_5 = 457;
    public static int sli5000_5 = 2999;

    public static int i5000_6 = 1598;
    public static int sli5000_6 = 199;
    public static int i5000_7 = 1597;
    public static int sli5000_7 = 199;
    public static int i5000_8 = 1596;
    public static int sli5000_8 = 199;

    /////////////////////////////////////////////////////////////// Moc 7000
    public static int i7000_1 = 457;
    public static int sli7000_1 = 8;

    public static int i7000_2 = 1619;
    public static int sli7000_2 = 19;

    public static int i7000_3 = 1472;
    public static int sli7000_3 = 1;
    public static int sdi7000_3 = 25;
//    public static int sdcmi7000_3 = 50;
//    public static int sddepi7000_3 = 15;

    public static int i7000_4 = 1599;
    public static int sli7000_4 = 299;

    public static int i7000_5 = 457;
    public static int sli7000_5 = 5999;

    public static int i7000_6 = 1598;
    public static int sli7000_6 = 299;
    public static int i7000_7 = 1597;
    public static int sli7000_7 = 299;
    public static int i7000_8 = 1596;
    public static int sli7000_8 = 299;

}
