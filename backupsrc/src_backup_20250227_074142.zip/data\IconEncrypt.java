/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

/**
 *
 * @author NgocThach
 */
public class IconEncrypt {
    public byte[] dataImageEncrypt;
    public String keyDecryptImage;
    public String keyOrigin;
}
