/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package List_Boss;

/**
 *
 * @author kagam
 */
public class MALONGCUUU {

   
}
